﻿namespace CarDealer;

using AutoMapper;

public class CarDealerProfile : Profile
{
    public CarDealerProfile()
    {

    }
}