﻿namespace P03_FootballBetting.Data.Common;

public class DbConfig
{
    public const string ConnectionString =
        @"Server=.; Database=FootballBetting; Integrated Security=true";
}