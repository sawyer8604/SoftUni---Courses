﻿namespace P03_FootballBetting.Data.Models.Enums;

public enum Prediction
{
    Draw = 0,
    Win = 1,
    Lose = 2
}