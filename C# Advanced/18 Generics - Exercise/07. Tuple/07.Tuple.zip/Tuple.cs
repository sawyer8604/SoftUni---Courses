﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.Tuple
{
    public class Tuple<T, T1>
    {

        public T Item1 { get; set; }
        public T1 Item2 { get; set; }
    }
}
