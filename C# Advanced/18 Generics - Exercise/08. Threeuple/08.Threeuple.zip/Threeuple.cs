﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08._Threeuple
{
    public class Threeuple<T, T1, T2>
    {
        public T item { get; set; }
        public T1 item1 { get; set; }
        public T2 item2 { get; set; }

    }
}
