﻿namespace CustomDoublyLinkedList
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
            CustomDoublyLinkedList<int> customLinkedList = new CustomDoublyLinkedList<int>();
        }
    }
}