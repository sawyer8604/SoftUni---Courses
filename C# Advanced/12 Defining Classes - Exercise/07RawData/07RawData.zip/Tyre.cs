﻿namespace _07.RawData
{
    public class Tyre
    {
        public int Age { get; set; }

        public double Pressure { get; set; }
    }
}