﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Person
{
    public class Person
    {
        public Person(string name, int age)
        {
            Name = name;
            Age = age;
        }

        // 1. Add Fields

        // 2. Add Constructor

        // 3. Add Properties

        // 4. Add Methods

        public string Name { get; set; }

        public int Age { get; set; }
    

        public override string ToString()
        {
            // Name: Peter, Age: 13

            StringBuilder sb = new StringBuilder();

            sb.Append($"Name: {this.Name}, Age: {this.Age}");

            return sb.ToString().TrimEnd();

        }

    }
}
