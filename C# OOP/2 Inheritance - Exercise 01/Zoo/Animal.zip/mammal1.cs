﻿namespace Zoo
{
    public class mammal
    {
    }
}