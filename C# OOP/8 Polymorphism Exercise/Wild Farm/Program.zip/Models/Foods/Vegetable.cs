﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wild_Farm.Models.Foods
{
    public class Vegetable : Food
    {
        public Vegetable(string type, int quantity)
            : base(type, quantity)
        {
        }
    }
}
