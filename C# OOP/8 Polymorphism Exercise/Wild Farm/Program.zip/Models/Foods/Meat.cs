﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wild_Farm.Models.Foods
{
    public class Meat : Food
    {
        public Meat(string type, int quantity) 
            : base(type, quantity)
        {
        }
    }
}
