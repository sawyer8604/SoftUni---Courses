﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wild_Farm.Models.Foods
{
    public class Seeds : Food
    {
        public Seeds(string type, int quantity)
            : base(type, quantity)
        {
        }
    }
}
