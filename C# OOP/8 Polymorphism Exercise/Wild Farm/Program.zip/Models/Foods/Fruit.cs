﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wild_Farm.Models.Foods
{
    public class Fruit : Food
    {
        public Fruit(string type, int quantity)
            : base(type, quantity)
        {
        }
    }
}
