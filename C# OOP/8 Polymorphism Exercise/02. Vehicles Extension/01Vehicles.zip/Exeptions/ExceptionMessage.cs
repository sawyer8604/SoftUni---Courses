﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Exeptions
{
    public class ExceptionMessage
    {
        public const string CanNotFitFuel = "Cannot fit {0} fuel in the tank";
        public const string FuelCannotBeAZero = "Fuel must be a positive number";
    }
}
