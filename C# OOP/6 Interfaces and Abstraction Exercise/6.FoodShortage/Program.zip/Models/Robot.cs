﻿namespace FoodShortage.Models
{
    public class Robot
    {
        public string Model { get; private set; }
        public int Id { get; private set; }
    }
}
