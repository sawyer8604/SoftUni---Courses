﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}

