﻿
namespace _08.CollectionHierarchy.Models.Interfaces
{
    public interface IMyList : IAddRemoveCollection
    {
        public int Used { get;}
    }
}
