﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.BirthdayCelebrations.Models.Interfaces
{
    public interface IBirthdate
    {
        public string Birthdate { get;}
    }
}
