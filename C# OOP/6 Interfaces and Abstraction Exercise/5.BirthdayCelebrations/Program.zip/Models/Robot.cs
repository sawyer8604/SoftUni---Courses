﻿using _05.BirthdayCelebrations.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace _05.BirthdayCelebrations.Models
{
    public class Robot
    {
        public string Model { get; private set; }
        public int Id { get; private set; }
    }
}
