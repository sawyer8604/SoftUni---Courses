﻿
namespace _03.ShoppingSpree
{
    public static class ExeptionMessages
    {
        public const string moneycannotBeNegative = "Money cannot be negative";
        public const string nameCannotBeEmpty = "Name cannot be empty";
    }
}